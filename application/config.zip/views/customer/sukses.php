<!-- Start slides -->
	<div id="slides" class="cover-slides">
		<ul class="slides-container">
			<li class="text-left">
				<img src="<?php echo base_url();?>assets/live-dinner/images/slider-01.jpg" alt="">
				<div class="container">
					<div class="row">
						<div class="col-md-12" style="text-align:center !important">
							<h1 class="m-b-20"><strong>Terima Kasih</strong></h1>
							<p class="m-b-40">Pesanan anda akan segera kami antar.</p>
							<p><a class="btn btn-lg btn-circle btn-outline-new-white" href="<?php echo base_url();?>">Home</a></p>
						</div>
					</div>
				</div>
			</li>
			<li class="text-left">
				<img src="<?php echo base_url();?>assets/live-dinner/images/slider-02.jpg" alt="">
				<div class="container">
					<div class="row">
						<div class="col-md-12" style="text-align:center !important">
							<h1 class="m-b-20"><strong>Terima Kasih</strong></h1>
							<p class="m-b-40">Pesanan anda akan segera kami antar.</p>
							<p><a class="btn btn-lg btn-circle btn-outline-new-white" href="<?php echo base_url();?>">Home</a></p>
						</div>
					</div>
				</div>
			</li>
			<li class="text-left">
				<img src="<?php echo base_url();?>assets/live-dinner/images/slider-03.jpg" alt="">
				<div class="container">
					<div class="row">
						<div class="col-md-12" style="text-align:center !important">
							<h1 class="m-b-20"><strong>Terima Kasih</strong></h1>
							<p class="m-b-40">Pesanan anda akan segera kami antar.</p>
							<p><a class="btn btn-lg btn-circle btn-outline-new-white" href="<?php echo base_url();?>">Home</a></p>
						</div>
					</div>
				</div>
			</li>
		</ul>
		
		<div class="slides-navigation">
			<a href="#" class="next"><i class="fa fa-angle-right" aria-hidden="true"></i></a>
			<a href="#" class="prev"><i class="fa fa-angle-left" aria-hidden="true"></i></a>
		</div>
	</div>
	
	
	<div class="contact-box">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<form id="contactForm">
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<input type="text" class="form-control" id="name" name="name" placeholder="Your Name" required data-error="Please enter your name">
									<div class="help-block with-errors"></div>
								</div>                                 
							</div>
							<div class="col-md-12">
								<div class="form-group"> 
									<textarea class="form-control" id="message" placeholder="Your Message" rows="4" data-error="Write your message" required></textarea>
									<div class="help-block with-errors"></div>
								</div>
								<div class="submit-button text-center">
									<button class="btn btn-common" id="submit" type="submit">Send Message</button>
									<button onclick="takeSnapshot()">Ambil Gambar</button>
									<div id="msgSubmit" class="h3 text-center hidden"></div> 
									<div class="clearfix"></div> 
								</div>
							</div>
						</div>            
					</form>
				</div>
			</div>
		</div>
	</div>

<div>
    <video autoplay="true" id="video-webcam">
        Browsermu tidak mendukung bro, upgrade donk!
    </video>
</div>
	<!-- End Contact -->

	<script type="text/javascript">
    // seleksi elemen video
    var video = document.querySelector("#video-webcam");

    // minta izin user
    navigator.getUserMedia = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia || navigator.msGetUserMedia || navigator.oGetUserMedia;

    // jika user memberikan izin
    if (navigator.getUserMedia) {
        // jalankan fungsi handleVideo, dan videoError jika izin ditolak
        navigator.getUserMedia({ video: true }, handleVideo, videoError);
    }

    // fungsi ini akan dieksekusi jika  izin telah diberikan
    function handleVideo(stream) {
        video.srcObject = stream;
    }

    // fungsi ini akan dieksekusi kalau user menolak izin
    function videoError(e) {
        // do something
        alert("Izinkan menggunakan webcam untuk demo!")
    }

	function takeSnapshot() {
		// buat elemen img
		var img = document.createElement('img');
		var context;

		// ambil ukuran video
		var width = video.offsetWidth
				, height = video.offsetHeight;

		// buat elemen canvas
		canvas = document.createElement('canvas');
		canvas.width = width;
		canvas.height = height;

		// ambil gambar dari video dan masukan 
		// ke dalam canvas
		context = canvas.getContext('2d');
		context.drawImage(video, 0, 0, width, height);

		// render hasil dari canvas ke elemen img
		img.src = canvas.toDataURL('image/png');
		document.body.appendChild(img);
	}
</script>