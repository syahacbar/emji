<?php
class Home extends CI_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('m_menu');
		$this->load->model('m_kategori');
		$this->load->library('upload');
	}


	function index(){
		$x['data']=$this->m_menu->hot_promo();
		$this->load->view('customer/header');
		$this->load->view('customer/home',$x);
		$this->load->view('customer/footer');
	}

}