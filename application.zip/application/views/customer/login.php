<!-- Start slides -->
	<div id="slides" class="cover-slides">
		<ul class="slides-container">
			<li class="text-left">
				<img src="<?php echo base_url();?>assets/live-dinner/images/slider-01.jpg" alt="">
				<div class="container">
					<div class="row">
						<div class="col-md-12" style="text-align:center !important">
							<h1 class="m-b-20">Silahkan Scan <strong>QR-Code Yang Ada Dimeja</strong></h1>
						</div>
					</div>
				</div>
			</li>
			<li class="text-left">
				<img src="<?php echo base_url();?>assets/live-dinner/images/slider-02.jpg" alt="">
				<div class="container">
					<div class="row">
						<div class="col-md-12" style="text-align:center !important">
							<h1 class="m-b-20">Silahkan Scan <strong>QR-Code Yang Ada Dimeja</strong></h1>
						</div>
					</div>
				</div>
			</li>
			<li class="text-left">
				<img src="<?php echo base_url();?>assets/live-dinner/images/slider-03.jpg" alt="">
				<div class="container">
					<div class="row">
						<div class="col-md-12" style="text-align:center !important">
							<h1 class="m-b-20">Silahkan Scan <strong>QR-Code Yang Ada Dimeja</strong></h1>
						</div>
					</div>
				</div>
			</li>
		</ul>
		
		<div class="slides-navigation">
			<a href="#" class="next"><i class="fa fa-angle-right" aria-hidden="true"></i></a>
			<a href="#" class="prev"><i class="fa fa-angle-left" aria-hidden="true"></i></a>
		</div>
	</div>
	<!-- End slides -->