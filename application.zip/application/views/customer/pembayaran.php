            <div id="content">
				
				
				<a href="<?php echo base_url().'menu/cod'?>" class="o-buttons blue" style="border:none;height:37px;width:100%;text-align:center;"><span class="fa fa-gift"></span> Bayar di Tempat</a>
				<a href="<?php echo base_url().'menu/transfer_bank'?>" class="o-buttons red" style="border:none;height:37px;width:100%;text-align:center;"><span class="fa fa-exchange"></span> Transfer Bank</a>
				
				
			</div>